<?php
	$response = array();
	include 'db_connect.php';
	include 'functions.php';

	$inputJSON = file_get_contents('php://input');
	$input = json_decode($inputJSON, TRUE); //convert JSON into array
	if(isset($input['base_user_id']) && isset($input['job_id'])){
		$bid = $input['base_user_id'];
		$jid = $input['job_id'];
			$query = "DELETE FROM Applies WHERE base_user_id = '$bid' AND job_id = '$jid'";
			if($stmt = $con->prepare($query)){
				$stmt->execute();
				$response["status"] = 0;
				$response["message"] = "Deleted apply";
				$stmt->close();
			}
	}
	else{
		$response["status"] = 2;
		$response["message"] = "Missing mandatory parameters";
	}
	echo json_encode($response);
?>