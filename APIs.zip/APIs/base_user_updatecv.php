<?php
$response = array();
include 'db_connect.php';
include 'functions.php';
 
//Get the input request parameters
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE); //convert JSON into array
//Check for Mandatory parameters
if(isset($input['id']) && isset($input['phone_number']) && isset($input['full_name'])){
	$userID = $input['id'];
	$phoneNumber = $input['phone_number'];
	$fullName = $input['full_name'];
	
	//Check if user already exist
		$insertQuery  = "UPDATE BaseUser SET full_name = '$fullName', phone_number = '$phoneNumber' WHERE user_id = '$userID'";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "User updated";
			$stmt->close();
		}
	else{
		$response["status"] = 1;
		$response["message"] = "User exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}
echo json_encode($response);
?>