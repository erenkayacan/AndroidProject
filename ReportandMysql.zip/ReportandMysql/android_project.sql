-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 03, 2020 at 10:47 AM
-- Server version: 5.7.28-0ubuntu0.18.04.4
-- PHP Version: 7.2.24-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `android_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `Applies`
--

CREATE TABLE `Applies` (
  `id` int(6) UNSIGNED NOT NULL,
  `base_user_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Applies`
--

INSERT INTO `Applies` (`id`, `base_user_id`, `job_id`) VALUES
(3, 4, 5),
(5, 4, 7),
(6, 4, 8);

-- --------------------------------------------------------

--
-- Table structure for table `BaseUser`
--

CREATE TABLE `BaseUser` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `password_hash` varchar(256) NOT NULL,
  `salt` varchar(256) NOT NULL,
  `phone_number` varchar(13) DEFAULT NULL,
  `StatusTypeId` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BaseUser`
--

INSERT INTO `BaseUser` (`user_id`, `username`, `full_name`, `password_hash`, `salt`, `phone_number`, `StatusTypeId`, `created_date`) VALUES
(4, 'erenkycn', 'Eren', '$2y$10$FZMVLABy18lgw1mXdI4ISuuFiwM/VyYFlqi1.ZVo9rIQ35NbQ6nVS', 'a7680d721318e70026a749a128a10a7bcff4e3c35466fbde408784d4ec0a464e', '123456789', NULL, '2019-12-17 15:32:22'),
(6, 'akn', 'akin olcaydu', '$2y$10$FMJMs7E3xII5YTN2XuuYEuf5B4yM1gcGAjsG7ihnSRCJYyAymYq92', '83134ee1e2e91eb4c0fe05784a0fd9bb20204cad89707f155feecedefb627dc0', NULL, NULL, '2019-12-23 16:31:26'),
(7, 'eren', 'eren', '$2y$10$Mw4nieqfyxseOuugy.PDxumguTX0meF7qvN7JxrcRJcYr7CLKj53O', '1b98781af2b5423e86954631938803d424c5ebb3d17609411c4c6ff582288631', NULL, NULL, '2019-12-25 19:30:31'),
(8, 'mtn', 'eren', '$2y$10$QN1LN.5i9kK6COo9E2vSQeIi6tUHsDvYtj7ZmT9fjr6/IkKaQITN2', '787d9a70716c6e665323e7b53adb2e546ec51ac1bd422e552cb75823f1ea72b4', '12341324', NULL, '2019-12-26 13:44:01'),
(9, 'buse', 'buse', '$2y$10$oOe50Bao.1ybbhGmG4954.8H1jaUwZ2SQZjvY/Vq6dp8T6yI7onae', '755932d5e7f49cd889061c61643866c86db42553dc20368fefd80e6daba1f881', NULL, NULL, '2020-01-03 01:26:06'),
(10, '123', 'akn', '$2y$10$tG0uwmuEO6fZ/uweUjre8OBl/DtOFZkRtmfnjjJelqfyykU0Tpi62', 'cf797ecf3aa69e6d89e15c155837521667b543ea46a53c093b8a274541c37bc0', NULL, NULL, '2020-01-03 01:26:33');

-- --------------------------------------------------------

--
-- Table structure for table `firmalar`
--

CREATE TABLE `firmalar` (
  `id` int(11) NOT NULL,
  `eposta` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `sifre` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `firmaadi` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `firmayetkilisi` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `sektor` text COLLATE utf8_turkish_ci NOT NULL,
  `calisansayisi` int(11) NOT NULL,
  `telefon` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `adres` text COLLATE utf8_turkish_ci NOT NULL,
  `profilresmi` text COLLATE utf8_turkish_ci NOT NULL,
  `uyetipi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Dumping data for table `firmalar`
--

INSERT INTO `firmalar` (`id`, `eposta`, `sifre`, `firmaadi`, `firmayetkilisi`, `sektor`, `calisansayisi`, `telefon`, `adres`, `profilresmi`, `uyetipi`) VALUES
(1, 'avagarage@gmail.com', '96a216ea77cb4fa9a9162b10d3a1b1d0', 'AVA Garage', 'Tunahan AKÇAY', 'Bilişim ve Reklamcılık', 5, '02129094369', 'Ayazma yolu Cad. No : 56 Kağıthane / İstanbul', 'images/firmalar/-firma.png', 1),
(2, 'eren.kayacan1@gmail.com', '3777541235e7e4ef47a405ebeaa88b83', 'Eren Company', 'Eren KAYACAN', 'SAP Consultant', 10, '5374460818', 'Florya Istanbul aa', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ilanlar`
--

CREATE TABLE `ilanlar` (
  `id` int(11) NOT NULL,
  `firmaid` int(11) NOT NULL,
  `ilanbasligi` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `calismasekli` varchar(255) COLLATE utf8_turkish_ci NOT NULL,
  `alinacakkisi` varchar(11) COLLATE utf8_turkish_ci NOT NULL,
  `ilanmetni` text COLLATE utf8_turkish_ci NOT NULL,
  `tarih` date NOT NULL,
  `kategori` varchar(15) COLLATE utf8_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Dumping data for table `ilanlar`
--

INSERT INTO `ilanlar` (`id`, `firmaid`, `ilanbasligi`, `calismasekli`, `alinacakkisi`, `ilanmetni`, `tarih`, `kategori`) VALUES
(1, 1, 'Sosyal Medya Uzmanı', 'Tam zamanlı', '2', 'Yinelenen bir sayfa i&ccedil;eriğinin okuyucunun dikkatini dağıttığı bilinen bir ger&ccedil;ektir.', '2019-05-28', 'yazılım'),
(5, 2, 'Junior Developer', 'Part Tıme', '7', 'Iyi Derecede Bilen', '2019-03-30', 'yazılım'),
(6, 2, 'Saglik', 'Tam zamanlı', '3', 'a', '2019-05-25', 'saglık'),
(7, 1, 'Mimar', 'Part Tıme', '3', 'b', '2019-05-24', 'mımar'),
(8, 1, 'Avukat', 'Part Tıme', '3', 'c', '2019-05-23', 'avukat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Applies`
--
ALTER TABLE `Applies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `base_user_id` (`base_user_id`),
  ADD KEY `job_id` (`job_id`);

--
-- Indexes for table `BaseUser`
--
ALTER TABLE `BaseUser`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `firmalar`
--
ALTER TABLE `firmalar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ilanlar`
--
ALTER TABLE `ilanlar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_i_f` (`firmaid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Applies`
--
ALTER TABLE `Applies`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `BaseUser`
--
ALTER TABLE `BaseUser`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Applies`
--
ALTER TABLE `Applies`
  ADD CONSTRAINT `Applies_ibfk_1` FOREIGN KEY (`base_user_id`) REFERENCES `BaseUser` (`user_id`),
  ADD CONSTRAINT `Applies_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `ilanlar` (`id`);

--
-- Constraints for table `ilanlar`
--
ALTER TABLE `ilanlar`
  ADD CONSTRAINT `fk_i_f` FOREIGN KEY (`firmaid`) REFERENCES `firmalar` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
